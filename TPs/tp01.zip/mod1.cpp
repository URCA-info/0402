// mod1.cpp

int twice(int x) {
	return 2 * x;
}

int fun(int u) {
	return incr(twice(u));
}
