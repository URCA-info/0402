// mod2.cpp

int incr(int x) {
	return x+1;
}

int v = 4;